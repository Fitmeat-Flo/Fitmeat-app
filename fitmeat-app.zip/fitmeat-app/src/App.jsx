import React from 'react'

export default function App() {
  return <h1>Fitmeat App läuft 🎉</h1>
}
