# Fitmeat App

## Starten (lokal)
```bash
npm install
npm run dev
```

## Build für Deployment
```bash
npm run build
npm run preview
```
